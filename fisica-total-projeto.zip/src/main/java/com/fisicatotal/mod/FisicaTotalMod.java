package com.fisicatotal.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.ProjectileImpactEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Mod("fisicatotal")
public class FisicaTotalMod {

    private static final int MAX_TASKS_PER_TICK = 32;
    private static final int MAX_QUEUE_SIZE = 350;
    private static final int MAX_CASCADE_DEPTH = 10;

    private record PhysicsTask(BlockPos pos, int depth) {}

    private final Map<ResourceKey<Level>, Deque<PhysicsTask>> physicsQueues = new HashMap<>();

    public FisicaTotalMod() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void enqueue(ServerLevel level, BlockPos pos, int depth) {
        if (depth > MAX_CASCADE_DEPTH) {
            return;
        }
        Deque<PhysicsTask> queue = physicsQueues.computeIfAbsent(level.dimension(), k -> new ArrayDeque<>());
        if (queue.size() < MAX_QUEUE_SIZE) {
            queue.addLast(new PhysicsTask(pos.immutable(), depth));
        }
    }

    private void enqueueNeighbors(ServerLevel level, BlockPos center, int depth) {
        enqueue(level, center.above(), depth);
        for (Direction dir : Direction.Plane.HORIZONTAL) {
            enqueue(level, center.relative(dir), depth);
            enqueue(level, center.relative(dir).above(), depth);
        }
    }

    @SubscribeEvent
    public void onBlockPlace(BlockEvent.EntityPlaceEvent event) {
        if (!(event.getLevel() instanceof ServerLevel serverLevel)) {
            return;
        }
        BlockPos pos = event.getPos();
        enqueue(serverLevel, pos, 0);
        for (Direction dir : Direction.Plane.HORIZONTAL) {
            enqueue(serverLevel, pos.relative(dir), 1);
        }
    }

    @SubscribeEvent
    public void onBlockBreak(BlockEvent.BreakEvent event) {
        if (!(event.getLevel() instanceof ServerLevel serverLevel)) {
            return;
        }
        BlockPos pos = event.getPos();
        BlockState state = event.getState();

        spawnBlockDebris(serverLevel, pos, state, 18);
        enqueueNeighbors(serverLevel, pos, 0);

        if (state.is(BlockTags.LOGS)) {
            collapseTree(serverLevel, pos);
        }
    }

    private void collapseTree(ServerLevel level, BlockPos basePos) {
        for (int dy = 1; dy <= 14; dy++) {
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    BlockPos check = basePos.offset(dx, dy, dz);
                    if (!level.isLoaded(check)) {
                        continue;
                    }
                    BlockState st = level.getBlockState(check);
                    if (st.is(BlockTags.LOGS) || st.is(BlockTags.LEAVES)) {
                        enqueue(level, check, 2);
                    }
                }
            }
        }
    }

    @SubscribeEvent
    public void onExplosionDetonate(ExplosionEvent.Detonate event) {
        if (!(event.getLevel() instanceof ServerLevel serverLevel)) {
            return;
        }
        Vec3 center = event.getExplosion().getPosition();
        List<BlockPos> affected = event.getAffectedBlocks();
        RandomSource rand = serverLevel.getRandom();
        int launched = 0;

        Iterator<BlockPos> it = affected.iterator();
        while (it.hasNext()) {
            BlockPos pos = it.next();
            if (!serverLevel.isLoaded(pos)) {
                continue;
            }
            BlockState state = serverLevel.getBlockState(pos);
            if (!canTurnIntoFallingBlock(serverLevel, pos, state)) {
                continue;
            }
            if (launched < 65 && rand.nextFloat() < 0.75F) {
                it.remove();
                FallingBlockEntity falling = FallingBlockEntity.fall(serverLevel, pos, state);
                falling.setHurtsEntities(2.0F, 40);

                Vec3 dir = new Vec3(
                    pos.getX() + 0.5 - center.x,
                    pos.getY() + 0.8 - center.y,
                    pos.getZ() + 0.5 - center.z
                );
                double dist = Math.max(1.0, dir.length());
                Vec3 norm = dir.normalize();
                double power = Math.min(1.4, 2.2 / Math.sqrt(dist));

                falling.setDeltaMovement(
                    norm.x * power + (rand.nextDouble() - 0.5) * 0.25,
                    Math.max(0.35, norm.y * power + 0.35 + rand.nextDouble() * 0.25),
                    norm.z * power + (rand.nextDouble() - 0.5) * 0.25
                );
                falling.hasImpulse = true;
                launched++;
            }
            enqueueNeighbors(serverLevel, pos, 3);
        }
    }

    @SubscribeEvent
    public void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.level instanceof ServerLevel serverLevel)) {
            return;
        }

        Deque<PhysicsTask> queue = physicsQueues.get(serverLevel.dimension());
        if (queue != null && !queue.isEmpty()) {
            int processed = 0;
            Set<BlockPos> handledThisTick = new HashSet<>();
            while (!queue.isEmpty() && processed < MAX_TASKS_PER_TICK) {
                PhysicsTask task = queue.pollFirst();
                if (!handledThisTick.add(task.pos())) {
                    continue;
                }
                processBlockPhysics(serverLevel, task.pos(), task.depth());
                processed++;
            }
        }

        if (serverLevel.getGameTime() % 2 == 0) {
            for (Entity entity : serverLevel.getAllEntities()) {
                if (entity instanceof ItemEntity item && item.isInWater()) {
                    Vec3 vel = item.getDeltaMovement();
                    if (vel.y < 0.08) {
                        item.setDeltaMovement(vel.x * 0.95, vel.y + 0.045, vel.z * 0.95);
                    }
                }
            }
        }
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Player player = event.player;
        if (!(player.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        if (player.tickCount % 6 != 0 || player.isCreative() || player.isSpectator() || player.isShiftKeyDown() || !player.onGround()) {
            return;
        }

        BlockPos underPos = player.getOnPos();
        if (!serverLevel.isLoaded(underPos)) {
            return;
        }
        BlockState underState = serverLevel.getBlockState(underPos);
        if (!canTurnIntoFallingBlock(serverLevel, underPos, underState)) {
            return;
        }

        boolean airBelow = serverLevel.getBlockState(underPos.below()).isAir();
        boolean fragile = underState.getSoundType(serverLevel, underPos, player) == SoundType.GLASS
            || underState.is(BlockTags.LEAVES)
            || underState.is(BlockTags.SNOW)
            || getMaxOverhang(serverLevel, underPos, underState) == 0;

        if (airBelow && fragile && (player.isSprinting() || serverLevel.getRandom().nextFloat() < 0.25F)) {
            spawnBlockDebris(serverLevel, underPos, underState, 8);
            enqueue(serverLevel, underPos, 0);
        }
    }

    @SubscribeEvent
    public void onLivingFall(LivingFallEvent event) {
        LivingEntity entity = event.getEntity();
        if (!(entity.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        float distance = event.getDistance();
        if (distance < 4.5F) {
            return;
        }

        BlockPos impactPos = entity.blockPosition().below();
        BlockState impactState = serverLevel.getBlockState(impactPos);
        spawnBlockDebris(serverLevel, impactPos, impactState, 24);
        serverLevel.sendParticles(ParticleTypes.CLOUD, entity.getX(), entity.getY() + 0.1, entity.getZ(), 12, 0.8, 0.1, 0.8, 0.08);

        double radius = Math.min(6.0, 2.0 + distance * 0.25);
        AABB box = new AABB(impactPos).inflate(radius);
        for (Entity nearby : serverLevel.getEntitiesOfClass(Entity.class, box)) {
            if (nearby == entity) {
                continue;
            }
            Vec3 push = nearby.position().subtract(entity.position());
            if (push.lengthSqr() > 0.001) {
                Vec3 norm = push.normalize();
                double strength = Math.min(0.9, distance * 0.06);
                nearby.setDeltaMovement(nearby.getDeltaMovement().add(norm.x * strength, 0.25, norm.z * strength));
                nearby.hasImpulse = true;
            }
        }

        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                enqueue(serverLevel, impactPos.offset(dx, 0, dz), 2);
            }
        }
    }

    @SubscribeEvent
    public void onProjectileImpact(ProjectileImpactEvent event) {
        Projectile projectile = event.getProjectile();
        if (!(projectile.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        if (!(event.getRayTraceResult() instanceof BlockHitResult hit)) {
            return;
        }

        BlockPos pos = hit.getBlockPos();
        BlockState state = serverLevel.getBlockState(pos);
        if (state.getSoundType(serverLevel, pos, projectile) == SoundType.GLASS && state.getDestroySpeed(serverLevel, pos) >= 0) {
            spawnBlockDebris(serverLevel, pos, state, 20);
            serverLevel.destroyBlock(pos, true);
            serverLevel.playSound(null, pos, SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 1.0F, 1.0F);
            enqueueNeighbors(serverLevel, pos, 0);
        } else if (canTurnIntoFallingBlock(serverLevel, pos, state) && getMaxOverhang(serverLevel, pos, state) == 0) {
            enqueue(serverLevel, pos, 0);
        }
    }

    @SubscribeEvent
    public void onLivingDeath(LivingDeathEvent event) {
        LivingEntity entity = event.getEntity();
        if (!(entity.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        Entity attacker = event.getSource().getEntity();
        if (attacker != null) {
            Vec3 push = entity.position().subtract(attacker.position());
            if (push.lengthSqr() > 0.001) {
                Vec3 norm = push.normalize();
                entity.setDeltaMovement(norm.x * 0.85, 0.42, norm.z * 0.85);
                entity.hasImpulse = true;
            }
        }
        serverLevel.sendParticles(ParticleTypes.POOF, entity.getX(), entity.getY() + 0.5, entity.getZ(), 14, 0.35, 0.4, 0.35, 0.06);
    }

    private void processBlockPhysics(ServerLevel level, BlockPos pos, int depth) {
        if (!level.isLoaded(pos)) {
            return;
        }
        BlockState state = level.getBlockState(pos);
        if (!canTurnIntoFallingBlock(level, pos, state)) {
            return;
        }

        RandomSource rand = level.getRandom();
        boolean supported = hasSupport(level, pos, state);

        if (!supported) {
            FallingBlockEntity falling = FallingBlockEntity.fall(level, pos, state);
            falling.setHurtsEntities(2.0F, 40);
            falling.setDeltaMovement(
                (rand.nextDouble() - 0.5) * 0.14,
                0.04,
                (rand.nextDouble() - 0.5) * 0.14
            );
            falling.hasImpulse = true;
            spawnBlockDebris(level, pos, state, 5);
            enqueueNeighbors(level, pos, depth + 1);
            return;
        }

        if (depth < 5 && isLooseSlideBlock(state)) {
            Direction slideDir = findSlideDirection(level, pos);
            if (slideDir != null) {
                FallingBlockEntity sliding = FallingBlockEntity.fall(level, pos, state);
                sliding.setHurtsEntities(1.5F, 30);
                sliding.setDeltaMovement(
                    slideDir.getStepX() * 0.26,
                    0.14,
                    slideDir.getStepZ() * 0.26
                );
                sliding.hasImpulse = true;
                enqueue(level, pos.above(), depth + 1);
            }
        }
    }

    private boolean canTurnIntoFallingBlock(ServerLevel level, BlockPos pos, BlockState state) {
        if (state.isAir() || state.liquid() || !state.blocksMotion()) {
            return false;
        }
        if (state.getDestroySpeed(level, pos) < 0.0F) {
            return false;
        }
        if (state.hasBlockEntity() || level.getBlockEntity(pos) != null) {
            return false;
        }
        return true;
    }

    private boolean isLooseSlideBlock(BlockState state) {
        return state.getBlock() instanceof FallingBlock
            || state.is(BlockTags.SAND)
            || state.is(Blocks.GRAVEL)
            || state.is(Blocks.COBBLESTONE)
            || state.is(Blocks.COBBLED_DEEPSLATE)
            || state.is(BlockTags.SNOW);
    }

    private Direction findSlideDirection(ServerLevel level, BlockPos pos) {
        Direction[] dirs = new Direction[] { Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST };
        int start = level.getRandom().nextInt(dirs.length);
        for (int i = 0; i < dirs.length; i++) {
            Direction dir = dirs[(start + i) % dirs.length];
            BlockPos side = pos.relative(dir);
            BlockPos sideBelow = side.below();
            if (!level.isLoaded(side) || !level.isLoaded(sideBelow)) {
                continue;
            }
            BlockState sideState = level.getBlockState(side);
            BlockState sideBelowState = level.getBlockState(sideBelow);
            if (!sideState.blocksMotion() && !sideBelowState.blocksMotion()) {
                return dir;
            }
        }
        return null;
    }

    private boolean isSolidSupport(ServerLevel level, BlockPos pos) {
        if (!level.isLoaded(pos)) {
            return true;
        }
        BlockState state = level.getBlockState(pos);
        return !state.isAir() && !state.liquid() && state.blocksMotion();
    }

    private boolean hasSupport(ServerLevel level, BlockPos startPos, BlockState startState) {
        if (isSolidSupport(level, startPos.below())) {
            return true;
        }

        int maxReach = getMaxOverhang(level, startPos, startState);
        if (maxReach <= 0) {
            return false;
        }

        Deque<BlockPos> queue = new ArrayDeque<>();
        Map<BlockPos, Integer> distances = new HashMap<>();
        queue.addLast(startPos);
        distances.put(startPos, 0);

        while (!queue.isEmpty()) {
            BlockPos current = queue.pollFirst();
            int dist = distances.get(current);
            if (dist >= maxReach) {
                continue;
            }

            for (Direction dir : Direction.Plane.HORIZONTAL) {
                BlockPos next = current.relative(dir);
                if (distances.containsKey(next)) {
                    continue;
                }
                if (!level.isLoaded(next)) {
                    return true;
                }
                BlockState nextState = level.getBlockState(next);
                if (nextState.isAir() || nextState.liquid() || !nextState.blocksMotion()) {
                    continue;
                }
                if (nextState.getDestroySpeed(level, next) < 0.0F || isSolidSupport(level, next.below())) {
                    return true;
                }
                if (getMaxOverhang(level, next, nextState) > dist) {
                    distances.put(next, dist + 1);
                    queue.addLast(next);
                }
            }
        }

        return false;
    }

    private int getMaxOverhang(ServerLevel level, BlockPos pos, BlockState state) {
        if (isLooseSlideBlock(state)
            || state.is(BlockTags.DIRT)
            || state.is(BlockTags.LEAVES)
            || state.getSoundType(level, pos, null) == SoundType.GLASS) {
            return 0;
        }
        if (state.is(Blocks.OBSIDIAN)
            || state.is(Blocks.CRYING_OBSIDIAN)
            || state.is(Blocks.IRON_BLOCK)
            || state.is(Blocks.NETHERITE_BLOCK)
            || state.getDestroySpeed(level, pos) >= 5.0F) {
            return 5;
        }
        if (state.is(BlockTags.LOGS)) {
            return 1;
        }
        if (state.is(BlockTags.PLANKS) || state.getSoundType(level, pos, null) == SoundType.WOOD) {
            return 2;
        }
        if (state.is(BlockTags.BASE_STONE_OVERWORLD)
            || state.is(BlockTags.BASE_STONE_NETHER)
            || state.is(BlockTags.STONE_BRICKS)
            || state.is(Blocks.BRICKS)
            || state.getSoundType(level, pos, null) == SoundType.STONE) {
            return 3;
        }
        return 1;
    }

    private void spawnBlockDebris(ServerLevel level, BlockPos pos, BlockState state, int count) {
        if (state.isAir()) {
            return;
        }
        BlockParticleOption particle = new BlockParticleOption(ParticleTypes.BLOCK, state);
        level.sendParticles(
            particle,
            pos.getX() + 0.5,
            pos.getY() + 0.5,
            pos.getZ() + 0.5,
            count,
            0.35,
            0.35,
            0.35,
            0.12
        );
    }
}
